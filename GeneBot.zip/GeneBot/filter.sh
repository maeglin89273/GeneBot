#!/bin/sh
python3 source/tableFilter.py output/analysis_table.txt -c 20 -t 50