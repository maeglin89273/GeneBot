#!/bin/sh
python3 source/geneBot.py GeneSym.txt -o -200 -l 200 -w 25 -t 20