#!/bin/sh
python3 source/analysisFetcher.py output/analysis_backup.txt -w 25